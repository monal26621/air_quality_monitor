# app.py

from flask import Flask, render_template, request
import numpy as np
import joblib
import os

print(os.getcwd())

# Load trained model

model = joblib.load(r"C:\Users\USER\OneDrive\Desktop\air_quality\model.pkl.pkl")

scaler = joblib.load(r"C:\Users\USER\OneDrive\Desktop\air_quality\scaler.pkl.pkl")

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get input values from form
        temperature = float(request.form['temperature'])
        humidity = float(request.form['humidity'])
        pm25 = float(request.form['pm25'])
        pm10 = float(request.form['pm10'])
        no2 = float(request.form['no2'])
        so2 = float(request.form['so2'])
        co = float(request.form['co'])

        features = np.array([[temperature, humidity, pm25, pm10, no2, so2, co]])
        

        # Convert to numpy array
        features = np.array([[temperature, humidity, pm25, pm10, no2]])

        # Scale input
        scaled_features = scaler.transform(features)

        # Predict
        prediction = model.predict(scaled_features)

        output = round(prediction[0], 2)

        return render_template(
            'index.html',
            prediction_text=f'Predicted AQI Value: {output}'
        )

    except Exception as e:
        return render_template(
            'index.html',
            prediction_text=f'Error: {str(e)}'
        )


if __name__ == "__main__":
    app.run(debug=False)